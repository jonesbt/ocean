is.in.grid <- function(x, y, grid)
    return(find.elem(x, y, grid) > 0)
