bathy.colors <- function(n, alpha=1)
    cols <- rgb(seq(0.9,0,len=n), seq(0.9,0,len=n), 1, alpha)
