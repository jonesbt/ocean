is.in.grid <- function(x, y, grid, units='ll')
    return(find.elem(x, y, grid, units) > 0)
